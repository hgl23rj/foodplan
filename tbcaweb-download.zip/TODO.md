# Entregas

## Consulta nutricional navegável
- [x] Criar uma aplicação web em português do Brasil para consultar a composição nutricional de alimentos.
- [x] Permitir buscar alimentos por nome ou código.
- [x] Disponibilizar filtros por grupo e tipo de alimento.
- [x] Exibir uma lista de resultados com informações resumidas de cada alimento.
- [x] Abrir um painel detalhado do alimento selecionado com valores por 100 g.

## Organização e confiança dos dados
- [x] Organizar os nutrientes em energia, macronutrientes, fibras, minerais e vitaminas.
- [x] Identificar visivelmente que os dados locais são demonstrativos e não representam uma consulta oficial em tempo real.
- [x] Exibir referência e direcionamento para a fonte pública da TBCA.

## Interface e entrega
- [x] Reutilizar a linguagem visual limpa do HTML fornecido, substituindo a seção de bioativos pela consulta nutricional.
- [x] Garantir comportamento responsivo em telas pequenas e grandes.
- [x] Servir a rota declarada em `public/manus-routes.json` e disponibilizar a aplicação no Preview do projeto.
